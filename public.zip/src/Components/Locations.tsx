import React, { useState, useEffect } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, CircularProgress, Alert, Box } from '@mui/material';
import apiClient from '../apiClient';

interface Location {
  id: number;
  name: string;
  description: string;
  
}

const Locations: React.FC = () => {
  const [locations, setLocations] = useState<Location[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchLocations = async () => {
      try {
        const response = await apiClient.get<Location[]>('/auth/locations');
        setLocations(response.data);
      } catch (err: any) {
        setError(err.message || 'Error fetching locations');
      } finally {
        setLoading(false);
      }
    };

    fetchLocations();
  }, []);

  if (loading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        height="100vh"
      >
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        height="100vh"
      >
        <Alert severity="error">Error: {error}</Alert>
      </Box>
    );
  }

  return (
    <Box
      display="flex"
      justifyContent="center"
      padding={10}
    >
      <TableContainer component={Paper} style={{ maxWidth: '80%' }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell align="center"><strong>Codigo</strong></TableCell>
              <TableCell align="center"><strong>Nombre</strong></TableCell>
              <TableCell align="center"><strong>Fecha creacion</strong></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {locations.data.map((location) => (
              <TableRow key={location.id}>
                <TableCell align="center">{location.code}</TableCell>
                <TableCell align="center">{location.name}</TableCell>
                <TableCell align="center">{location.created_at}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default Locations;